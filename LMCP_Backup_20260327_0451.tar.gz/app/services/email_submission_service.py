from __future__ import annotations

import mimetypes
import os
import smtplib
from email.message import EmailMessage
from pathlib import Path
from typing import Iterable, List, Optional


class EmailSubmissionError(Exception):
    pass


class EmailSubmissionService:
    @staticmethod
    def _get_env(name: str, default: Optional[str] = None, required: bool = False) -> str:
        value = os.getenv(name, default)
        if required and not value:
            raise EmailSubmissionError(f"Missing required environment variable: {name}")
        return value or ""

    @classmethod
    def is_enabled(cls) -> bool:
        return cls._get_env("SMTP_ENABLED", "false").strip().lower() in {"1", "true", "yes", "on"}

    @classmethod
    def _build_message(
        cls,
        *,
        to_email: str,
        subject: str,
        body: str,
        attachment_paths: Optional[Iterable[str]] = None,
        cc_email: Optional[str] = None,
    ) -> EmailMessage:
        from_email = cls._get_env("SMTP_FROM", required=True)
        from_name = cls._get_env("SMTP_FROM_NAME", "LMCP AutoQuote")
        msg = EmailMessage()
        msg["From"] = f"{from_name} <{from_email}>"
        msg["To"] = to_email
        msg["Subject"] = subject

        if cc_email:
            msg["Cc"] = cc_email

        msg.set_content(body)

        for attachment_path in attachment_paths or []:
            path = Path(attachment_path)
            if not path.exists() or not path.is_file():
                raise EmailSubmissionError(f"Attachment file not found: {attachment_path}")

            mime_type, _ = mimetypes.guess_type(str(path))
            if mime_type:
                maintype, subtype = mime_type.split("/", 1)
            else:
                maintype, subtype = "application", "octet-stream"

            with path.open("rb") as f:
                msg.add_attachment(
                    f.read(),
                    maintype=maintype,
                    subtype=subtype,
                    filename=path.name,
                )

        return msg

    @classmethod
    def send_email(
        cls,
        *,
        to_email: str,
        subject: str,
        body: str,
        attachment_paths: Optional[Iterable[str]] = None,
        cc_email: Optional[str] = None,
    ) -> dict:
        if not cls.is_enabled():
            raise EmailSubmissionError("SMTP is not enabled. Set SMTP_ENABLED=true in .env")

        smtp_host = cls._get_env("SMTP_HOST", required=True)
        smtp_port = int(cls._get_env("SMTP_PORT", "587"))
        smtp_username = cls._get_env("SMTP_USERNAME", required=True)
        smtp_password = cls._get_env("SMTP_PASSWORD", required=True)

        msg = cls._build_message(
            to_email=to_email,
            subject=subject,
            body=body,
            attachment_paths=attachment_paths,
            cc_email=cc_email,
        )

        recipients: List[str] = [to_email]
        if cc_email:
            recipients.extend([x.strip() for x in cc_email.split(",") if x.strip()])

        try:
            with smtplib.SMTP(smtp_host, smtp_port, timeout=30) as server:
                server.ehlo()
                server.starttls()
                server.ehlo()
                server.login(smtp_username, smtp_password)
                server.send_message(msg, to_addrs=recipients)

            return {
                "success": True,
                "message": "Email sent successfully",
                "to": to_email,
                "cc": cc_email,
                "subject": subject,
                "attachments": list(attachment_paths or []),
            }

        except smtplib.SMTPAuthenticationError as exc:
            raise EmailSubmissionError(
                "SMTP authentication failed. Check your iCloud email address and app-specific password."
            ) from exc
        except Exception as exc:
            raise EmailSubmissionError(f"Failed to send email: {exc}") from exc

    @classmethod
    def send_quote_pdf(
        cls,
        *,
        to_email: str,
        pdf_path: str,
        quotation_number: Optional[str] = None,
        company_name: Optional[str] = None,
        cc_email: Optional[str] = None,
    ) -> dict:
        path = Path(pdf_path)
        if not path.exists() or not path.is_file():
            raise EmailSubmissionError(f"Quote PDF not found: {pdf_path}")

        subject = f"Quotation Submission{f' - {quotation_number}' if quotation_number else ''}"

        customer_name = company_name or "Client"

        body = (
            f"Dear {customer_name},\n\n"
            f"Please find attached our quotation in PDF format.\n\n"
            f"Regards,\n"
            f"Lechesa Manaba Consulting and Projects (Pty) Ltd"
        )

        return cls.send_email(
            to_email=to_email,
            subject=subject,
            body=body,
            attachment_paths=[str(path)],
            cc_email=cc_email,
        )
