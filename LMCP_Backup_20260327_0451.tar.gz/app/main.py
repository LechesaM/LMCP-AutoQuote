from __future__ import annotations

import importlib
import logging
from typing import Any, Dict, List, Tuple

from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware
from app.api.tender_pipeline_api import router as tender_pipeline_router
from app.api.quote_engine_api import router as quote_engine_router
from app.api.quote_pack_api import router as quote_pack_router
from app.api.live_autoquote_api import router as live_autoquote_router
from app.api.submission_pipeline_api import router as submission_pipeline_router
from app.email_api import router as email_router
from app.api.test_pricing_api import router as test_pricing_router
from app.autonomous_api import router as autonomous_router
from app.tasks_api import router as tasks_router

logger = logging.getLogger(__name__)
logging.basicConfig(level=logging.INFO)


app = FastAPI(
    title="LMCP AutoQuote System",
    description="LMCP Autonomous Tender Harvesting, Quote Generation, Compliance, and Submission Platform",
    version="2.1.0",
)

app.include_router(tender_pipeline_router)
app.include_router(quote_engine_router)
app.include_router(quote_pack_router)
app.include_router(live_autoquote_router)
app.include_router(submission_pipeline_router)
app.include_router(email_router)
app.include_router(test_pricing_router)
app.include_router(autonomous_router)
app.include_router(tasks_router)

# ---------------------------------------------------------
# CORS
# ---------------------------------------------------------
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# ---------------------------------------------------------
# Router load tracking
# ---------------------------------------------------------
LOADED_ROUTERS: List[str] = []
FAILED_ROUTERS: List[Tuple[str, str]] = []


def load_router(import_path: str, name: str) -> None:
    try:
        module = importlib.import_module(import_path)
        router = getattr(module, "router", None)

        if router is None:
            raise AttributeError("No 'router' object found")

        app.include_router(router)
        LOADED_ROUTERS.append(name)
        logger.info("Loaded router: %s (%s)", name, import_path)

    except Exception as exc:
        FAILED_ROUTERS.append((name, str(exc)))
        logger.warning("Failed to load router %s from %s: %s", name, import_path, exc)


# ---------------------------------------------------------
# Root / health endpoints
# ---------------------------------------------------------
@app.get("/", tags=["System"])
def root() -> Dict[str, Any]:
    return {
        "status": "ok",
        "message": "LMCP AutoQuote API is running",
        "version": app.version,
    }


@app.get("/health", tags=["System"])
def health() -> Dict[str, Any]:
    return {
        "status": "ok",
        "service": "lmcp-autoquote-api",
        "version": app.version,
        "loaded_router_count": len(LOADED_ROUTERS),
        "failed_router_count": len(FAILED_ROUTERS),
    }


@app.get("/router-status", tags=["System"])
def router_status() -> Dict[str, Any]:
    return {
        "status": "ok",
        "loaded_routers": LOADED_ROUTERS,
        "failed_routers": [
            {"name": name, "error": error}
            for name, error in FAILED_ROUTERS
        ],
    }


# ---------------------------------------------------------
# ROUTER LOAD ORDER
# Load most stable / core routers first,
# then feature routers, then newer app/api routers.
# ---------------------------------------------------------

# Core / existing root-level routers
load_router("app.audit_api", "audit_api")
load_router("app.compliance_api", "compliance_api")
#load_router("app.dashboard_api", "dashboard_api")
load_router("app.email_api", "email_api")
load_router("app.harvester_api", "harvester_api")
#load_router("app.opportunities_api", "opportunities_api")
#load_router("app.quote_api", "quote_api")
#load_router("app.quote_pack_api", "quote_pack_api")
#load_router("app.relevance_api", "relevance_api")
load_router("app.sbd_api", "sbd_api")
#load_router("app.submission_api", "submission_api")
load_router("app.system_guard_api", "system_guard_api")
#load_router("app.system_routes", "system_routes")
#load_router("app.ui_routes", "ui_routes")

# New structured API routers under app/api
load_router("app.api.autonomous_api", "autonomous_api")
load_router("app.api.dashboard", "dashboard")
load_router("app.api.form_filler_api", "form_filler_api")
load_router("app.api.revenue_dashboard_api", "revenue_dashboard_api")
load_router("app.api.sbd_version_detector_api", "sbd_version_detector_api")
load_router("app.api.self_healing_harvester", "self_healing_harvester")
#load_router("app.api.stability", "stability")
load_router("app.api.supervisor", "supervisor")
load_router("app.api.supply_command_api", "supply_command_api")
load_router("app.api.system", "system_api")
load_router("app.api.tender_form_priority_api", "tender_form_priority_api")
#load_router("app.api.tender_pipeline_api", "tender_pipeline_api")
#load_router("app.api.tender_submission_pipeline_api", "tender_submission_pipeline_api")

# Optional legacy / engine routers


# ---------------------------------------------------------
# Startup / Shutdown
# ---------------------------------------------------------
@app.on_event("startup")
async def startup_event() -> None:
    logger.info("LMCP AutoQuote API startup complete")
    logger.info("Loaded routers: %s", LOADED_ROUTERS)
    if FAILED_ROUTERS:
        logger.warning("Failed routers: %s", FAILED_ROUTERS)


@app.on_event("shutdown")
async def shutdown_event() -> None:
    logger.info("LMCP AutoQuote API shutdown complete")
