from __future__ import annotations

import logging
from typing import Any, Dict

from fastapi import APIRouter, HTTPException

from app.services.autonomous_engine import get_autonomous_status, run_autonomous_cycle

logger = logging.getLogger(__name__)

router = APIRouter(prefix="/autonomous", tags=["autonomous"])


@router.get("/status")
def autonomous_status() -> Dict[str, Any]:
    return {
        "ok": True,
        "message": "Autonomous status retrieved successfully.",
        "data": get_autonomous_status(),
    }


@router.post("/run-once")
def autonomous_run_once() -> Dict[str, Any]:
    try:
        from app.services.live_supply_pipeline import analyze_live_rfqs
        result = analyze_live_rfqs()
        return {
            "ok": result.get("success", False),
            "message": result.get("message", "Autonomous cycle finished."),
            "data": result,
        }
    except Exception as exc:
        logger.exception("Autonomous run-once failed: %s", exc)
        raise HTTPException(status_code=500, detail=f"Autonomous run failed: {exc}")
