from __future__ import annotations

import importlib
import logging
from concurrent.futures import ThreadPoolExecutor, TimeoutError as FuturesTimeoutError
from datetime import datetime, timezone
from typing import Any, Dict, List

from app.celery_app import celery
from app.services.tender_harvester import run_national_tender_radar
from app.services.tender_pipeline import run_tender_pipeline_batch_from_harvest

logger = logging.getLogger(__name__)


def _now_iso() -> str:
    return datetime.now(timezone.utc).isoformat()


def _safe_len(value: Any) -> int:
    if isinstance(value, list):
        return len(value)
    return 0


def _extract_harvest_items(harvest_result: Any) -> List[Dict[str, Any]]:
    if isinstance(harvest_result, list):
        return [item for item in harvest_result if isinstance(item, dict)]

    if not isinstance(harvest_result, dict):
        return []

    candidates = [
        harvest_result.get("items"),
        harvest_result.get("opportunities"),
        harvest_result.get("results"),
        harvest_result.get("data"),
        harvest_result.get("candidates"),
    ]

    for candidate in candidates:
        if isinstance(candidate, list):
            return [item for item in candidate if isinstance(item, dict)]

    return []


def _build_task_summary(
    task_name: str,
    status: str,
    message: str,
    **extra: Any,
) -> Dict[str, Any]:
    payload: Dict[str, Any] = {
        "task": task_name,
        "status": status,
        "message": message,
        "updated_at": _now_iso(),
    }
    payload.update(extra)
    return payload


def _run_harvester() -> Any:
    """
    Stable autonomous harvester order based on real callable signatures.

    Order:
    1. app.services.tender_harvester.run_national_tender_radar(db=None)
    2. app.tender_harvester.harvest_etenders()
    3. app.harvester.harvest_opportunities(...) fallback
    """
    # 1) National tender radar service
    try:
        service_module = importlib.import_module("app.services.tender_harvester")
        radar_fn = getattr(service_module, "run_national_tender_radar", None)
        if callable(radar_fn):
            logger.info("Using app.services.tender_harvester.run_national_tender_radar(db=None)")
            result = radar_fn(db=None)
            if result is not None:
                return result
    except Exception as exc:
        logger.exception("run_national_tender_radar failed: %s", exc)

    # 2) Direct eTenders harvester
    try:
        et_module = importlib.import_module("app.tender_harvester")
        et_fn = getattr(et_module, "harvest_etenders", None)
        if callable(et_fn):
            logger.info("Using app.tender_harvester.harvest_etenders()")
            result = et_fn()
            if result is not None:
                return result
    except Exception as exc:
        logger.exception("harvest_etenders failed: %s", exc)

    # 3) Generic harvester fallback
    harvester_module = importlib.import_module("app.harvester")

    full_fn = getattr(harvester_module, "harvest_opportunities", None)
    if callable(full_fn):
        logger.info("Using app.harvester.harvest_opportunities() fallback")
        return full_fn(
            include_parser_router=True,
            include_department_scraper=False,
            include_homepage_only=False,
            include_needs_custom_parser=True,
            min_confidence=5,
            entity_type_filter=None,
            limit_sources=10,
        )

    quick_fn = getattr(harvester_module, "harvest_opportunities_quick", None)
    if callable(quick_fn):
        logger.info("Fallback to app.harvester.harvest_opportunities_quick()")
        return quick_fn()

    available = [name for name in dir(harvester_module) if not name.startswith("_")]
    raise AttributeError(
        "No supported harvester entry point found. "
        f"Available names in app.harvester: {available}"
    )


def _run_with_timeout(fn, timeout_seconds: int) -> Any:
    executor = ThreadPoolExecutor(max_workers=1)
    future = executor.submit(fn)

    try:
        return future.result(timeout=timeout_seconds)
    except FuturesTimeoutError:
        future.cancel()
        executor.shutdown(wait=False, cancel_futures=True)
        raise
    except Exception:
        executor.shutdown(wait=False, cancel_futures=True)
        raise
    finally:
        if future.done():
            executor.shutdown(wait=True, cancel_futures=True)


@celery.task(name="app.tasks.health_check")
def health_check() -> Dict[str, Any]:
    return _build_task_summary(
        task_name="health_check",
        status="ok",
        message="Celery worker is healthy",
    )


@celery.task(name="app.tasks.run_harvest_only")
def run_harvest_only() -> Dict[str, Any]:
    try:
        harvest_result = _run_with_timeout(_run_harvester, timeout_seconds=90)
        items = _extract_harvest_items(harvest_result)

        return _build_task_summary(
            task_name="run_harvest_only",
            status="ok",
            message="Harvest completed",
            harvested_count=len(items),
            harvest_result=harvest_result,
        )

    except FuturesTimeoutError:
        logger.exception("run_harvest_only timed out")
        return _build_task_summary(
            task_name="run_harvest_only",
            status="failed",
            message="Harvest task timed out after 90 seconds",
        )
    except Exception as exc:
        logger.exception("run_harvest_only failed")
        return _build_task_summary(
            task_name="run_harvest_only",
            status="failed",
            message=f"Harvest task failed: {exc}",
        )


@celery.task(name="app.tasks.run_pipeline_from_items")
def run_pipeline_from_items(items: List[Dict[str, Any]]) -> Dict[str, Any]:
    try:
        from app.services.tender_pipeline import run_tender_pipeline_batch_from_harvest

        pipeline_result = run_tender_pipeline_batch_from_harvest(items or [])

        return _build_task_summary(
            task_name="run_pipeline_from_items",
            status="ok",
            message="Pipeline run completed",
            input_count=_safe_len(items),
            pipeline_result=pipeline_result,
        )

    except Exception as exc:
        logger.exception("run_pipeline_from_items failed")
        return _build_task_summary(
            task_name="run_pipeline_from_items",
            status="failed",
            message=f"Pipeline task failed: {exc}",
            input_count=_safe_len(items),
        )


@celery.task(name="app.tasks.run_harvest_pipeline")
def run_harvest_pipeline():
    try:
        # STEP 1: Harvest RFQs
        items = run_national_tender_radar()

        # STEP 2: Send to pipeline
        pipeline_result = run_tender_pipeline_batch_from_harvest(items)

        return {
            "status": "ok",
            "message": "Harvest + pipeline completed",
            "harvest_count": len(items or []),
            "pipeline_result": pipeline_result
        }

    except Exception as e:
        return {
            "status": "failed",
            "message": f"Harvest + pipeline task failed: {str(e)}"
        }


@celery.task(name="app.tasks.run_autonomous_cycle")
def run_autonomous_cycle() -> Dict[str, Any]:
    try:
        result = run_harvest_pipeline()

        status = result.get("status", "ok")
        message = result.get("message", "Autonomous cycle completed")

        return _build_task_summary(
            task_name="run_autonomous_cycle",
            status=status,
            message=message,
            cycle_result=result,
        )

    except Exception as exc:
        logger.exception("run_autonomous_cycle failed")
        return _build_task_summary(
            task_name="run_autonomous_cycle",
            status="failed",
            message=f"Autonomous cycle failed: {exc}",
        )
