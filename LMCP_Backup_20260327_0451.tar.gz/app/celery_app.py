from __future__ import annotations

from celery import Celery

celery = Celery(
    "lmcp_worker",
    broker="redis://redis:6379/0",
    backend="redis://redis:6379/0",
)

celery.conf.update(
    timezone="Africa/Johannesburg",
    enable_utc=False,
    task_serializer="json",
    accept_content=["json"],
    result_serializer="json",
    worker_prefetch_multiplier=1,
    task_acks_late=True,
    task_track_started=True,
    broker_connection_retry_on_startup=True,
)

# Import task module so Celery registers all task names used by the API/worker
import app.tasks  # noqa: F401

# Keep beat schedule aligned to tasks that actually exist
celery.conf.beat_schedule = {
    "run-autonomous-cycle-every-30-minutes": {
        "task": "app.tasks.run_autonomous_cycle",
        "schedule": 30 * 60,
    },
}
