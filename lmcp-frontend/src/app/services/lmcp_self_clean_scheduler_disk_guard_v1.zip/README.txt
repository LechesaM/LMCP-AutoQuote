Install:
cd /Users/Shared/LMCP-AutoQuote-Server

cp ~/Downloads/self_clean_scheduler_service.py app/services/self_clean_scheduler_service.py
cp ~/Downloads/self_clean_scheduler_api.py app/api/self_clean_scheduler_api.py
mkdir -p app/tasks
cp ~/Downloads/self_clean_scheduler.py app/tasks/self_clean_scheduler.py

Add to app/main.py OPTIONAL_ROUTERS:
("self_clean_scheduler_router", "app.api.self_clean_scheduler_api", "router"),

Verify:
python3 -m py_compile app/services/self_clean_scheduler_service.py app/api/self_clean_scheduler_api.py app/tasks/self_clean_scheduler.py app/main.py
docker compose restart api
sleep 8

Test:
curl http://localhost:8000/self-clean-scheduler/status
curl http://localhost:8000/self-clean-scheduler/disk-guard
curl -X POST "http://localhost:8000/self-clean-scheduler/run?dry_run=true"
curl -X POST "http://localhost:8000/self-clean-scheduler/enforce?auto_archive=true"
