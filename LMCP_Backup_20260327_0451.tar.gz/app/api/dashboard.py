from fastapi import APIRouter
from app.services.portal_radar_service import get_portal_radar_summary
from app.services.procurement_heatmap import build_procurement_heatmap

router = APIRouter(prefix="/dashboard", tags=["Dashboard"])

@router.get("/system-health")
def dashboard_system_health():

    portal_radar = get_portal_radar_summary()

    return {
        "system_status": "ok",
        "portal_radar": portal_radar,
        "ui_flags": {
            "show_national_procurement_radar": True
        }
    }
