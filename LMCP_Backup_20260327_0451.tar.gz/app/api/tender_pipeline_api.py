from __future__ import annotations

from typing import Any, Dict, List, Optional

from fastapi import APIRouter
from pydantic import BaseModel, Field

from app.services.live_rfq_store import LiveRFQStore
from app.services.tender_pipeline import run_tender_pipeline_from_payload

router = APIRouter(prefix="/tender-pipeline", tags=["Tender Pipeline"])


class TenderPipelineRunRequest(BaseModel):
    payload: Dict[str, Any] = Field(default_factory=dict)
    source: str = "manual"
    persist_to_live_store: bool = True


@router.get("/health", operation_id="tp_health")
def tender_pipeline_health() -> Dict[str, Any]:
    return {
        "ok": True,
        "service": "tender-pipeline",
    }


@router.get("/demo", operation_id="tp_demo")
def tender_pipeline_demo() -> Dict[str, Any]:
    return {
        "ok": True,
        "service": "tender-pipeline",
        "available_routes": [
            "/tender-pipeline/health",
            "/tender-pipeline/demo",
            "/tender-pipeline/run",
            "/tender-pipeline/test-run",
            "/tender-pipeline/live-rfqs",
            "/tender-pipeline/filtered-live-rfqs",
            "/tender-pipeline/scored-live-rfqs",
            "/tender-pipeline/recommended-live-rfqs",
        ],
    }


@router.post("/run", operation_id="tp_run_pipeline")
def run_pipeline(request: TenderPipelineRunRequest) -> Dict[str, Any]:
    source = getattr(request, "source", None) or "manual_test"

    result = run_tender_pipeline_from_payload(
        payload=request.payload or {},
        source=source,
    )

    result_dict = result.model_dump() if hasattr(result, "model_dump") else dict(result)

    harvest_result = result_dict.get("harvest_result") or {}
    harvested_items = harvest_result.get("items") or []

    return {
        "ok": True,
        "message": "Tender pipeline executed successfully.",
        "result": result_dict,
        "summary": {
            "source": source,
            "harvested_count": len(harvested_items),
        },
    }

@router.get("/test-run", operation_id="tp_test_run_pipeline")
def test_run_pipeline() -> Dict[str, Any]:
    sample_payload: Dict[str, Any] = {
        "title": "Test Supply and Delivery RFQ",
        "description": (
            "Supply and delivery of general office furniture and related items "
            "with no compulsory briefing session."
        ),
        "category": "supply_and_delivery",
        "estimated_value": 250000,
        "briefing_session": False,
        "province": "Gauteng",
    }

    result = run_tender_pipeline_from_payload(
        payload=sample_payload,
        source="test",
        persist_to_live_store=False,
    )

    harvest_result = result.get("harvest_result") or {}
    harvested_items = harvest_result.get("items") or []

    return {
        "ok": True,
        "message": "Tender pipeline test run completed.",
        "result": result,
        "summary": {
            "source": "test",
            "raw_result_keys": list((harvest_result.get("raw_result") or {}).keys()),
            "harvested_count": len(harvested_items),
        },
    }


@router.get("/live-rfqs", operation_id="tp_get_live_rfqs")
def get_live_rfqs() -> Dict[str, Any]:
    return LiveRFQStore.get_all()


@router.get("/filtered-live-rfqs", operation_id="tp_get_filtered_live_rfqs")
def get_filtered_live_rfqs() -> Dict[str, Any]:
    return LiveRFQStore.get_filtered_from_store()


@router.get("/scored-live-rfqs", operation_id="tp_get_scored_live_rfqs")
def get_scored_live_rfqs() -> Dict[str, Any]:
    return LiveRFQStore.get_scored_from_store()


@router.get("/recommended-live-rfqs", operation_id="tp_get_recommended_live_rfqs")
def get_recommended_live_rfqs() -> Dict[str, Any]:
    data = LiveRFQStore.get_scored_from_store()
    return {
        "updated_at": data.get("updated_at"),
        "count": data.get("recommended_count", 0),
        "items": data.get("recommended_items", []),
    }
