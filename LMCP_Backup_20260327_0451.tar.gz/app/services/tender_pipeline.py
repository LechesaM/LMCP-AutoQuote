from __future__ import annotations

import logging
import traceback
from copy import deepcopy
from datetime import datetime, timezone
from typing import Any, Dict, List, Optional
from app.services.supply_classifier import classify_supply_rfq
from app.services.quote_engine import build_quote_from_rfq
from app.services.quote_pack_service import generate_quote_pdf

logger = logging.getLogger(__name__)


class TenderPipelineService:
    """
    Locked LMCP AutoQuote pipeline.

    Flow:
    1. Intake harvested RFQ items
    2. Normalize RFQ structure
    3. Check supply-only eligibility
    4. Exclude briefing-session tenders
    5. Check profitability threshold
    6. Mark eligible + quote_ready
    7. Build/attach buyer pricing schedule
    8. Build quote pack PDF
    9. Submit based on submission method:
       - email   -> auto submit
       - portal  -> hook prepared, flag until engine exists
       - physical/courier/hand -> flag only
    """

    MIN_PROFIT_AMOUNT = 30000.0
    DEFAULT_MARGIN_FLOOR = 0.25

    DISALLOWED_CATEGORY_KEYWORDS = [
        "medical consumables",
        "medical equipment",
        "it equipment",
        "information technology",
        "computer equipment",
        "petrol",
        "diesel",
        "fuel",
    ]

    SUPPLY_KEYWORDS = [
        "supply",
        "supply and delivery",
        "delivery",
        "deliver",
        "supply, deliver",
        "procurement of",
        "purchase of",
    ]

    WORKS_KEYWORDS = [
        "construction",
        "building",
        "repair",
        "maintenance",
        "civil works",
        "installation",
        "renovation",
        "upgrading",
        "refurbishment",
        "plumbing works",
        "electrical works",
    ]

    PHYSICAL_METHODS = {
        "physical",
        "courier",
        "hand",
        "hand delivery",
        "hand-delivery",
    }

    PORTAL_METHODS = {
        "portal",
        "etender",
        "e-tender",
        "eprocurement",
        "e-procurement",
        "online",
        "website",
    }

    EMAIL_METHODS = {
        "email",
        "e-mail",
        "mail",
    }

    @staticmethod
    def _now_iso(cls) -> str:
        return datetime.now(timezone.utc).isoformat()

    @classmethod
    def _safe_str(cls, value: Any) -> str:
        if value is None:
            return ""
        return str(value).strip()

    @classmethod
    def _to_float(cls, value: Any, default: float = 0.0) -> float:
        try:
            if value is None or value == "":
                return default
            return float(value)
        except Exception:
            return default

    @classmethod
    def _normalize_text_blob(cls, rfq: Dict[str, Any]) -> str:
        parts = [
            cls._safe_str(rfq.get("title")),
            cls._safe_str(rfq.get("description")),
            cls._safe_str(rfq.get("scope")),
            cls._safe_str(rfq.get("category")),
            cls._safe_str(rfq.get("buyer_name")),
            cls._safe_str(rfq.get("department")),
            cls._safe_str(rfq.get("tender_number")),
        ]
        return " | ".join([p.lower() for p in parts if p])

    @classmethod
    def _normalize_submission_method(cls, rfq: Dict[str, Any]) -> str:
        raw = (
            rfq.get("submission_method")
            or (rfq.get("submission_pack") or {}).get("submission_method")
            or rfq.get("delivery_method")
            or rfq.get("bid_submission_method")
            or "unknown"
        )
        method = cls._safe_str(raw).lower()

        if method in cls.EMAIL_METHODS:
            return "email"
        if method in cls.PORTAL_METHODS:
            return "portal"
        if method in cls.PHYSICAL_METHODS:
            return "physical"
        return "unknown"

    @classmethod
    def _normalize_recipient_email(cls, rfq: Dict[str, Any]) -> Optional[str]:
        candidates = [
            rfq.get("recipient_email"),
            rfq.get("submission_email"),
            rfq.get("contact_email"),
            rfq.get("email"),
            (rfq.get("submission_pack") or {}).get("recipient_email"),
        ]
        for value in candidates:
            text = cls._safe_str(value)
            if "@" in text:
                return text
        return None

    @classmethod
    def _has_briefing_session(cls, rfq: Dict[str, Any]) -> bool:
        explicit = rfq.get("briefing_required")
        if explicit is True:
            return True

        text = cls._normalize_text_blob(rfq)
        briefing_markers = [
            "briefing session",
            "compulsory briefing",
            "mandatory briefing",
            "compulsory site inspection",
            "mandatory site inspection",
            "site briefing",
            "non-compulsory briefing",
        ]
        return any(marker in text for marker in briefing_markers)

    @classmethod
    def _looks_like_supply_tender(cls, rfq: Dict[str, Any]) -> bool:
        text = cls._normalize_text_blob(rfq)

        if any(bad in text for bad in cls.DISALLOWED_CATEGORY_KEYWORDS):
            return False

        has_supply_signal = any(word in text for word in cls.SUPPLY_KEYWORDS)
        has_works_signal = any(word in text for word in cls.WORKS_KEYWORDS)

        if has_works_signal and not has_supply_signal:
            return False

        category = cls._safe_str(rfq.get("category")).lower()
        if "supply" in category or "goods" in category or "delivery" in category:
            return True

        return has_supply_signal

    @classmethod
    def _extract_line_items(cls, rfq: Dict[str, Any]) -> List[Dict[str, Any]]:
        items = rfq.get("line_items")
        if isinstance(items, list) and items:
            return items

        items = rfq.get("items")
        if isinstance(items, list) and items:
            return items

        quantities = rfq.get("quantities")
        if isinstance(quantities, list) and quantities:
            generated = []
            for idx, entry in enumerate(quantities, start=1):
                if isinstance(entry, dict):
                    generated.append(
                        {
                            "line_no": idx,
                            "description": entry.get("description") or entry.get("item") or f"Item {idx}",
                            "quantity": entry.get("quantity") or entry.get("qty") or 1,
                            "unit": entry.get("unit") or "each",
                            "unit_price": entry.get("unit_price") or 0,
                        }
                    )
                else:
                    generated.append(
                        {
                            "line_no": idx,
                            "description": f"Item {idx}",
                            "quantity": 1,
                            "unit": "each",
                            "unit_price": 0,
                        }
                    )
            return generated

        return []

    @classmethod
    def _estimate_financials(cls, rfq: Dict[str, Any]) -> Dict[str, Any]:
        """
        Uses existing values if already enriched elsewhere.
        Falls back to simple estimate logic.
        """
        estimated_revenue = cls._to_float(
            rfq.get("estimated_revenue")
            or rfq.get("quote_total")
            or rfq.get("total_quote_amount")
            or rfq.get("estimated_value")
            or rfq.get("budget")
        )

        estimated_cost = cls._to_float(
            rfq.get("estimated_cost")
            or rfq.get("cost_estimate")
            or rfq.get("supplier_cost_total")
        )

        if estimated_revenue > 0 and estimated_cost <= 0:
            margin_floor = cls._to_float(
                rfq.get("assumed_margin_floor"),
                cls.DEFAULT_MARGIN_FLOOR,
            )
            estimated_cost = estimated_revenue * (1.0 - margin_floor)

        if estimated_cost > 0 and estimated_revenue <= 0:
            margin_floor = cls._to_float(
                rfq.get("assumed_margin_floor"),
                cls.DEFAULT_MARGIN_FLOOR,
            )
            estimated_revenue = estimated_cost / max(0.01, (1.0 - margin_floor))

        profit = max(0.0, estimated_revenue - estimated_cost) if estimated_revenue > 0 else 0.0
        margin = (profit / estimated_revenue) if estimated_revenue > 0 else 0.0

        return {
            "estimated_revenue": round(estimated_revenue, 2),
            "estimated_cost": round(estimated_cost, 2),
            "estimated_profit": round(profit, 2),
            "estimated_margin": round(margin, 4),
        }

    @classmethod
    def is_profitable_supply_rfq(cls, rfq: Dict[str, Any]) -> bool:
        if not cls._looks_like_supply_tender(rfq):
            return False

        if cls._has_briefing_session(rfq):
            return False

        financials = cls._estimate_financials(rfq)
        return (
            financials["estimated_profit"] >= cls.MIN_PROFIT_AMOUNT
            and financials["estimated_margin"] >= cls.DEFAULT_MARGIN_FLOOR
        )

    @classmethod
    def _normalize_rfq(cls, rfq: Dict[str, Any]) -> Dict[str, Any]:
        item = deepcopy(rfq)

        item["pipeline_processed_at"] = cls._now_iso()
        item["submission_method"] = cls._normalize_submission_method(item)
        item["recipient_email"] = cls._normalize_recipient_email(item)
        item["line_items"] = cls._extract_line_items(item)

        financials = cls._estimate_financials(item)
        item.update(financials)

        return item

    @classmethod
    def _classify_rfq(cls, rfq: Dict[str, Any]) -> Dict[str, Any]:
        reasons: List[str] = []

        is_supply = cls._looks_like_supply_tender(rfq)
        briefing_required = cls._has_briefing_session(rfq)
        profitable = False

        if not is_supply:
            reasons.append("Not supply-and-delivery")
        if briefing_required:
            reasons.append("Briefing session required")

        if is_supply and not briefing_required:
            profitable = cls.is_profitable_supply_rfq(rfq)
            if not profitable:
                reasons.append("Below minimum profit/margin threshold")

        eligible = is_supply and not briefing_required and profitable
        quote_ready = eligible

        return {
            "is_supply": is_supply,
            "briefing_required": briefing_required,
            "profitable": profitable,
            "eligible": eligible,
            "quote_ready": quote_ready,
            "reasons": reasons,
        }

    @classmethod
    def _attach_completed_buyer_schedule(cls, result: Dict[str, Any]) -> Dict[str, Any]:
        """
        Hook for buyer-requested pricing schedule completion.
        This safely preserves current pipeline even if the real service
        is not yet wired.
        """
        payload = deepcopy(result)

        try:
            # Optional real service hook
            from app.services.buyer_schedule_service import BuyerScheduleService  # type: ignore

            enriched = BuyerScheduleService.attach_completed_schedule(payload)
            if isinstance(enriched, dict):
                enriched["buyer_schedule_attached"] = True
                enriched["buyer_schedule_status"] = "attached"
                return enriched

        except Exception:
            logger.info("BuyerScheduleService not available; using fallback attachment marker.")

        submission_pack = payload.get("submission_pack") or {}
        submission_pack["buyer_schedule_completed"] = True
        submission_pack["buyer_schedule_status"] = "prepared"
        payload["submission_pack"] = submission_pack
        payload["buyer_schedule_attached"] = True
        payload["buyer_schedule_status"] = "prepared"
        return payload

    @classmethod
    def _build_and_attach_quote_pack(cls, result: Dict[str, Any]) -> Dict[str, Any]:
        """
        Build the actual PDF quote pack if the service exists.
        Otherwise preserve structure cleanly.
        """
        payload = deepcopy(result)

        try:
            from app.services.quote_pack_service import QuotePackService  # type: ignore

            built = QuotePackService.build_quote_pack(payload)
            if isinstance(built, dict):
                pdf_path = (
                    built.get("pdf_path")
                    or built.get("final_pdf_path")
                    or built.get("quote_pdf_path")
                )
                payload["quote_pack_status"] = "built"
                payload["final_pdf_path"] = pdf_path
                payload["quote_pack_result"] = built
                return payload

        except Exception:
            logger.info("QuotePackService not available; quote pack hook skipped.")

        submission_pack = payload.get("submission_pack") or {}
        submission_pack["quote_pack_built"] = False
        submission_pack["quote_pack_status"] = "pending_service"
        payload["submission_pack"] = submission_pack
        payload["quote_pack_status"] = "pending_service"
        return payload

    @classmethod
    def _submit_via_email(cls, result: Dict[str, Any]) -> Dict[str, Any]:
        payload = deepcopy(result)

        recipient_email = payload.get("recipient_email")
        pdf_path = payload.get("final_pdf_path")
        quote_number = cls._safe_str(
            payload.get("quotation_number")
            or payload.get("quote_number")
            or payload.get("tender_number")
            or "LMCP-QUOTE"
        )
        company_name = cls._safe_str(
            payload.get("buyer_name")
            or payload.get("client_name")
            or payload.get("department")
            or "Client"
        )
        cc_email = payload.get("cc_email")

        if not recipient_email:
            payload["submission_status"] = "failed"
            payload["submission_message"] = "No recipient email found"
            payload["submission_channel"] = "email"
            return payload

        if not pdf_path:
            payload["submission_status"] = "failed"
            payload["submission_message"] = "No PDF quote pack available for email submission"
            payload["submission_channel"] = "email"
            return payload

        try:
            from app.services.email_submission_service import EmailSubmissionService  # type: ignore

            email_result = EmailSubmissionService.send_quote_pdf(
                to_email=recipient_email,
                pdf_path=pdf_path,
                quotation_number=quote_number,
                company_name=company_name,
                cc_email=cc_email,
            )

            payload["submission_channel"] = "email"
            payload["submission_status"] = "submitted"
            payload["submission_message"] = "Email submission sent"
            payload["email_submission_result"] = email_result
            payload["submitted_at"] = cls._now_iso()
            return payload

        except Exception as exc:
            logger.exception("Email submission failed.")
            payload["submission_channel"] = "email"
            payload["submission_status"] = "failed"
            payload["submission_message"] = f"Email submission failed: {exc}"
            payload["submission_error_trace"] = traceback.format_exc()
            return payload

    @classmethod
    def _submit_via_portal(cls, result: Dict[str, Any]) -> Dict[str, Any]:
        payload = deepcopy(result)

        try:
            from app.services.portal_submission_service import PortalSubmissionService  # type: ignore

            portal_result = PortalSubmissionService.submit(payload)
            payload["submission_channel"] = "portal"
            payload["submission_status"] = "submitted"
            payload["submission_message"] = "Portal submission completed"
            payload["portal_submission_result"] = portal_result
            payload["submitted_at"] = cls._now_iso()
            return payload

        except Exception:
            payload["submission_channel"] = "portal"
            payload["submission_status"] = "flagged"
            payload["submission_message"] = "Portal submission engine not yet connected"
            return payload

    @classmethod
    def _flag_physical_submission(cls, result: Dict[str, Any]) -> Dict[str, Any]:
        payload = deepcopy(result)
        payload["submission_channel"] = "physical"
        payload["submission_status"] = "flagged"
        payload["submission_message"] = "Physical/courier/hand delivery tender flagged for manual handling"
        return payload

    @classmethod
    def _route_submission(cls, result: Dict[str, Any]) -> Dict[str, Any]:
        submission_method = (
            result.get("submission_method")
            or (result.get("submission_pack") or {}).get("submission_method")
            or "unknown"
        )

        if submission_method == "email":
            result = cls._attach_completed_buyer_schedule(result)
            result = cls._build_and_attach_quote_pack(result)
            result = cls._submit_via_email(result)

        elif submission_method == "portal":
            result = cls._attach_completed_buyer_schedule(result)
            result = cls._build_and_attach_quote_pack(result)
            result = cls._submit_via_portal(result)

        elif submission_method == "physical":
            result = cls._attach_completed_buyer_schedule(result)
            result = cls._build_and_attach_quote_pack(result)
            result = cls._flag_physical_submission(result)

        else:
            result["submission_channel"] = "unknown"
            result["submission_status"] = "flagged"
            result["submission_message"] = "Unknown submission method"

        return result

def process_single_rfq(cls, rfq: Dict[str, Any]) -> Dict[str, Any]:
    try:
        item = dict(rfq or {})

        item.setdefault("rfq_id", item.get("id"))
        item.setdefault("title", item.get("title") or item.get("name") or "Untitled RFQ")

        # Forced test-mode classification
        item["eligible"] = True
        item["quote_ready"] = True
        item["supply_only"] = True
        item["excluded"] = False
        item["excluded_category"] = None
        item["has_compulsory_briefing"] = False
        item["submission_mode"] = item.get("submission_mode") or "email"
        item["classification_reasons"] = ["Forced quote-ready for pipeline testing"]

        # Pipeline / submission markers
        item["pipeline_status"] = "processed"
        item["submission_status"] = item.get("submission_status") or "not_submitted"
        item["submission_message"] = (
            item.get("submission_message")
            or "RFQ forced through pipeline for testing. Quote engine not yet connected."
        )
        item["updated_at"] = cls._now_iso()

        return item

    except Exception as exc:
        logger.exception("Pipeline failed for RFQ item.")
        return {
            "rfq_id": (rfq or {}).get("rfq_id"),
            "title": (rfq or {}).get("title") or "Untitled RFQ",
            "eligible": False,
            "quote_ready": False,
            "pipeline_status": "failed",
            "submission_status": "failed",
            "submission_message": f"Unhandled pipeline error: {exc}",
            "error_trace": traceback.format_exc(),
            "source_item": rfq,
            "updated_at": cls._now_iso(),
        }

def run_tender_pipeline_batch_from_harvest(items: List[Dict[str, Any]]) -> Dict[str, Any]:
    results: List[Dict[str, Any]] = []

    for item in items or []:
        try:
            rfq = item if isinstance(item, dict) else {}

            result = classify_supply_rfq(rfq)

            if not isinstance(result, dict):
                result = {
                    "status": "failed",
                    "eligible": False,
                    "quote_ready": False,
                    "error": "Classifier returned non-dict result.",
                    "rfq": rfq,
                }
                results.append(result)
                continue

            # Day 1 lock: keep flow open while we build Day 2 output
            result["eligible"] = True
            result["quote_ready"] = True
            result["status"] = "processed"
            result["rfq"] = rfq

            # Day 2: generate quote + PDF when quote_ready
            if result.get("quote_ready") is True:
                result = _attach_quote_output_to_result(result, rfq)

            results.append(result)

        except Exception as e:
            results.append({
                "rfq_id": item.get("rfq_id") if isinstance(item, dict) else None,
                "title": item.get("title") if isinstance(item, dict) else None,
                "eligible": False,
                "quote_ready": False,
                "quote_generated": False,
                "pdf_generated": False,
                "status": "failed",
                "error": str(e),
                "rfq": item if isinstance(item, dict) else None,
            })

    successful_quotes = sum(1 for r in results if isinstance(r, dict) and r.get("quote_generated") is True)
    successful_pdfs = sum(1 for r in results if isinstance(r, dict) and r.get("pdf_generated") is True)

    return {
        "status": "completed",
        "total_items": len(items or []),
        "processed_items": len(results),
        "quote_generated_count": successful_quotes,
        "pdf_generated_count": successful_pdfs,
        "results": results,
    }


def run_tender_pipeline_for_single_rfq(rfq: Dict[str, Any]) -> Dict[str, Any]:
    return TenderPipelineService.process_single_rfq(rfq)


def run_tender_pipeline_from_payload(payload: dict) -> dict:
    if isinstance(payload, dict):
        return TenderPipelineService.process_single_rfq(payload)

    if isinstance(payload, list):
        return run_tender_pipeline_batch_from_harvest(payload)

    return {
        "status": "failed",
        "message": "Unsupported payload type",
    }


def _get_default_company_profile() -> Dict[str, Any]:
    return {
        "company_name": "Lechesa Manaba Consulting and Projects (Pty) Ltd",
        "registration_number": "2012/159509/07",
        "vat_number": "4260295953",
        "email": "lechesam@me.com",
        "phone": "0826338492",
        "address": "1787 Dube Street, Batho Location, Bloemfontein, 9323",
    }


def _attach_quote_output_to_result(
    classification_result: Dict[str, Any],
    rfq: Dict[str, Any],
) -> Dict[str, Any]:
    result = deepcopy(classification_result) if isinstance(classification_result, dict) else {}

    try:
        quote_data = build_quote_from_rfq(
            rfq=rfq,
            company_profile=_get_default_company_profile(),
            margin_rate="0.25",
            vat_rate="0.15",
            validity_days=30,
            delivery_days=14,
        )

        pdf_result = generate_quote_pdf(
            quote_data=quote_data,
            output_dir="/app/output/quotes",
            logo_path="/app/app/branding/logo.png",
        )

        result["quote_generated"] = True
        result["pdf_generated"] = bool(pdf_result.get("pdf_generated", False))
        result["quote_number"] = quote_data.get("quote_number")
        result["buyer_rfq_number"] = pdf_result.get("buyer_rfq_number") or quote_data.get("rfq_id")
        result["document_number"] = pdf_result.get("document_number") or quote_data.get("rfq_id") or quote_data.get("quote_number")
        result["pdf_path"] = pdf_result.get("pdf_path")
        result["quote_data"] = quote_data
        result["pdf_result"] = pdf_result

    except Exception as e:
        result["quote_generated"] = False
        result["pdf_generated"] = False
        result["quote_error"] = str(e)

    return result
