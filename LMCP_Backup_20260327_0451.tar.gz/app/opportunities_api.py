from __future__ import annotations

import logging
from datetime import datetime, timezone
from typing import Any, Dict, List

from fastapi import APIRouter

from app.tasks import manual_harvest

logger = logging.getLogger(__name__)

router = APIRouter(prefix="/rfq-opportunities", tags=["RFQ Opportunities"])


@router.post("/harvest", summary="Trigger RFQ Harvest into Live Store")
def harvest_opportunities() -> Dict[str, Any]:
    """
    Returns the current shared live RFQs.
    Falls back to manual harvest if the live store is empty.
    """
    try:
        from app.services.live_rfq_store import LiveRFQStore

        live_data = LiveRFQStore.get_all()
        live_items = live_data.get("items", []) if isinstance(live_data, dict) else []

        if live_items:
            return {
                "status": "ok",
                "source": "live_rfq_store",
                "updated_at": live_data.get("updated_at"),
                "count": len(live_items),
                "items": live_items,
            }

    except Exception:
        logger.exception("Failed reading LiveRFQStore")

    try:
        result = manual_harvest()

        return {
            "status": "ok",
            "source": "manual_harvest",
            "count": result.get("opportunities_found", 0),
            "items": result.get("opportunities", []),
        }

    except Exception as e:
        logger.exception("Harvest failed")
        return {
            "status": "error",
            "message": str(e),
        }


@router.get("/harvest/status")
def harvest_status() -> Dict[str, Any]:
    """
    Simple harvest status endpoint.
    """
    return {
        "status": "ok",
        "message": "Harvest service available",
        "timestamp": datetime.now(timezone.utc).isoformat(),
    }


@router.get("", summary="Get RFQ Opportunities")
def get_opportunities() -> Dict[str, Any]:
    """
    Returns the current shared live RFQs.
    Falls back to manual harvest if the live store is empty.
    """
    try:
        from app.services.live_rfq_store import LiveRFQStore

        live_data = LiveRFQStore.get_all()
        live_items = live_data.get("items", []) if isinstance(live_data, dict) else []

        if live_items:
            return {
                "status": "ok",
                "source": "live_rfq_store",
                "updated_at": live_data.get("updated_at"),
                "count": len(live_items),
                "items": live_items,
            }

    except Exception:
        logger.exception("Failed reading LiveRFQStore in get_opportunities")

    result = manual_harvest()

    return {
        "status": "ok",
        "source": "manual_harvest",
        "count": result.get("opportunities_found", 0),
        "items": result.get("opportunities", []),
    }

# ---------------------------------------------------------
# ✅ GUARANTEED ENDPOINTS (FOR SWAGGER VISIBILITY)
# ---------------------------------------------------------

from app.tasks import manual_harvest


@router.get("", summary="Get RFQ Opportunities")
def get_opportunities() -> Dict[str, Any]:
    result = manual_harvest()

    return {
        "status": "ok",
        "count": result.get("opportunities_found", 0),
        "items": result.get("opportunities", []),
    }


@router.get("/health", summary="Opportunities API Health")
def opportunities_health() -> Dict[str, str]:
    return {"status": "ok"}
