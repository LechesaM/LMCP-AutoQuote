from __future__ import annotations

import json
from pathlib import Path
from typing import Any, Dict, List


BASE_DIR = Path(__file__).resolve().parent
JSON_PATH = BASE_DIR / "lmcp_entity_master_seed.json"


def _load_seed_payload() -> Dict[str, Any]:
    if not JSON_PATH.exists():
        raise FileNotFoundError(
            f"Missing seed JSON file: {JSON_PATH}\n"
            "Place lmcp_entity_master_seed.json inside app/data/"
        )

    with open(JSON_PATH, "r", encoding="utf-8") as f:
        payload = json.load(f)

    if isinstance(payload, list):
        return {
            "ENTITY_MASTER_DB": payload,
            "SCHEDULER_HEATMAP_SEED": payload,
            "TIER_CONFIG": {
                "Tier 1": {
                    "label": "High Value / Low Frequency",
                    "entity_types": [
                        "national_department",
                        "soe",
                        "national_public_entity",
                        "constitutional_institution",
                    ],
                    "default_scan_cadence_minutes": 10,
                },
                "Tier 2": {
                    "label": "Medium Value / Medium Frequency",
                    "entity_types": [
                        "provincial_department",
                        "provincial_public_entity",
                    ],
                    "default_scan_cadence_minutes": 30,
                },
                "Tier 3": {
                    "label": "High Frequency / Volume",
                    "entity_types": [
                        "metro_municipality",
                        "district_municipality",
                        "local_municipality",
                    ],
                    "default_scan_cadence_minutes": 120,
                },
            },
            "CONTROL_LOGIC": {
                "strategy": "LMCP supply-and-delivery-only procurement targeting",
                "priority_layers": {
                    "Tier 1": "National Departments, SOEs, major national entities",
                    "Tier 2": "Provincial Departments and provincial public entities",
                    "Tier 3": "Municipalities",
                },
            },
        }

    if not isinstance(payload, dict):
        raise ValueError("Seed JSON must be either a list or a dictionary")

    entity_master_db = payload.get("ENTITY_MASTER_DB") or payload.get("entity_master_db") or []
    scheduler_heatmap_seed = (
        payload.get("SCHEDULER_HEATMAP_SEED")
        or payload.get("scheduler_heatmap_seed")
        or entity_master_db
    )

    tier_config = payload.get("TIER_CONFIG") or payload.get("tier_config") or {
        "Tier 1": {
            "label": "High Value / Low Frequency",
            "entity_types": [
                "national_department",
                "soe",
                "national_public_entity",
                "constitutional_institution",
            ],
            "default_scan_cadence_minutes": 10,
        },
        "Tier 2": {
            "label": "Medium Value / Medium Frequency",
            "entity_types": [
                "provincial_department",
                "provincial_public_entity",
            ],
            "default_scan_cadence_minutes": 30,
        },
        "Tier 3": {
            "label": "High Frequency / Volume",
            "entity_types": [
                "metro_municipality",
                "district_municipality",
                "local_municipality",
            ],
            "default_scan_cadence_minutes": 120,
        },
    }

    control_logic = payload.get("CONTROL_LOGIC") or payload.get("control_logic") or {
        "strategy": "LMCP supply-and-delivery-only procurement targeting",
        "priority_layers": {
            "Tier 1": "National Departments, SOEs, major national entities",
            "Tier 2": "Provincial Departments and provincial public entities",
            "Tier 3": "Municipalities",
        },
    }

    return {
        "ENTITY_MASTER_DB": entity_master_db,
        "SCHEDULER_HEATMAP_SEED": scheduler_heatmap_seed,
        "TIER_CONFIG": tier_config,
        "CONTROL_LOGIC": control_logic,
    }


_SEED = _load_seed_payload()

ENTITY_MASTER_DB: List[Dict[str, Any]] = _SEED["ENTITY_MASTER_DB"]
SCHEDULER_HEATMAP_SEED: List[Dict[str, Any]] = _SEED["SCHEDULER_HEATMAP_SEED"]
TIER_CONFIG: Dict[str, Any] = _SEED["TIER_CONFIG"]
CONTROL_LOGIC: Dict[str, Any] = _SEED["CONTROL_LOGIC"]


def get_all_entities() -> List[Dict[str, Any]]:
    return ENTITY_MASTER_DB


def get_scheduler_entities() -> List[Dict[str, Any]]:
    return SCHEDULER_HEATMAP_SEED


def get_entities_by_tier(tier: str) -> List[Dict[str, Any]]:
    return [
        entity
        for entity in ENTITY_MASTER_DB
        if str(entity.get("priority_tier", "")).strip() == str(tier).strip()
    ]


def get_entity_by_slug(slug: str) -> Dict[str, Any] | None:
    slug = str(slug).strip().lower()
    for entity in ENTITY_MASTER_DB:
        if str(entity.get("entity_slug", "")).strip().lower() == slug:
            return entity
    return None


def build_adaptive_crawl_seed() -> List[Dict[str, Any]]:
    return [
        entity
        for entity in SCHEDULER_HEATMAP_SEED
        if bool(entity.get("scheduler_enabled", True))
    ]


def build_procurement_heatmap_seed() -> List[Dict[str, Any]]:
    return [
        entity
        for entity in SCHEDULER_HEATMAP_SEED
        if bool(entity.get("heatmap_enabled", True))
    ]


if __name__ == "__main__":
    print(f"Loaded ENTITY_MASTER_DB: {len(ENTITY_MASTER_DB)}")
    print(f"Loaded SCHEDULER_HEATMAP_SEED: {len(SCHEDULER_HEATMAP_SEED)}")
