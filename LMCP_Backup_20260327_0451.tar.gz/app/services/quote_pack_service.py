from __future__ import annotations

from datetime import datetime
from decimal import Decimal, InvalidOperation
from pathlib import Path
from typing import Any, Dict, List, Optional

from reportlab.lib.pagesizes import A4
from reportlab.lib.units import mm
from reportlab.pdfbase.pdfmetrics import stringWidth
from reportlab.pdfgen import canvas


BASE_DIR = Path("/app")
OUTPUT_DIR = BASE_DIR / "output" / "quotes"

DEFAULT_SELLER_ADDRESS = "1787 Dube Street, Batho Location, Bloemfontein, 9323"
DEFAULT_SELLER_PHONE = "0826338492"
DEFAULT_SELLER_EMAIL = "lechesam@me.com"
DEFAULT_SELLER_REG_NO = "2012/159509/07"
DEFAULT_SELLER_VAT_NO = "4260295953"
DEFAULT_COMPANY_NAME = "Lechesa Manaba Consulting and Projects (Pty) Ltd"


def _safe_str(value: Any, default: str = "") -> str:
    if value is None:
        return default
    text = str(value).strip()
    return text if text else default


def _to_decimal(value: Any, default: str = "0.00") -> Decimal:
    try:
        if value is None:
            return Decimal(default)
        return Decimal(str(value).strip())
    except (InvalidOperation, ValueError, TypeError):
        return Decimal(default)


def _format_currency(value: Any) -> str:
    amount = _to_decimal(value, "0.00")
    return f"R {amount:,.2f}"


def _wrap_text(text: str, max_width: float, font_name: str, font_size: int) -> List[str]:
    text = _safe_str(text)
    if not text:
        return [""]

    words = text.split()
    if not words:
        return [""]

    lines: List[str] = []
    current = words[0]

    for word in words[1:]:
        candidate = f"{current} {word}"
        if stringWidth(candidate, font_name, font_size) <= max_width:
            current = candidate
        else:
            lines.append(current)
            current = word

    lines.append(current)
    return lines


def _safe_filename(value: str, default: str = "LMCP-QUOTE") -> str:
    cleaned = "".join(ch for ch in _safe_str(value, default) if ch.isalnum() or ch in {"-", "_"})
    return cleaned or default


def _extract_buyer_rfq_number(quote_data: Dict[str, Any]) -> str:
    source_rfq = quote_data.get("source_rfq", {}) or {}
    if not isinstance(source_rfq, dict):
        source_rfq = {}

    candidates = [
        quote_data.get("rfq_id"),
        quote_data.get("buyer_rfq_number"),
        quote_data.get("rfq_number"),
        quote_data.get("tender_number"),
        quote_data.get("reference_number"),
        source_rfq.get("rfq_id"),
        source_rfq.get("rfq_number"),
        source_rfq.get("buyer_rfq_number"),
        source_rfq.get("tender_number"),
        source_rfq.get("reference_number"),
        source_rfq.get("bid_number"),
        source_rfq.get("tender_id"),
        source_rfq.get("notice_id"),
        source_rfq.get("quotation_number"),
    ]

    for candidate in candidates:
        value = _safe_str(candidate)
        if value:
            return value

    return ""


def _resolve_document_number(quote_data: Dict[str, Any]) -> str:
    quote_number = _safe_str(quote_data.get("quote_number"))
    if quote_number:
        return quote_number

    buyer_rfq_number = _extract_buyer_rfq_number(quote_data)
    if buyer_rfq_number:
        return buyer_rfq_number

    return "LMCP-QUOTE"


class QuotePackService:
    @classmethod
    def generate_quote_pdf(
        cls,
        quote_data: Dict[str, Any],
        output_dir: Optional[str] = None,
        logo_path: Optional[str] = None,
    ) -> Dict[str, Any]:
        if not isinstance(quote_data, dict):
            raise ValueError("quote_data must be a dictionary.")

        document_number = _resolve_document_number(quote_data)
        safe_document_number = _safe_filename(document_number, default="LMCP-QUOTE")

        final_output_dir = Path(output_dir) if output_dir else OUTPUT_DIR
        final_output_dir.mkdir(parents=True, exist_ok=True)

        pdf_path = final_output_dir / f"{safe_document_number}.pdf"

        c = canvas.Canvas(str(pdf_path), pagesize=A4)
        width, height = A4
        c.setTitle(document_number)

        cls._draw_document(
            c=c,
            width=width,
            height=height,
            quote_data=quote_data,
            logo_path=logo_path,
            document_number=document_number,
        )

        c.save()

        return {
            "status": "completed",
            "quote_generated": True,
            "pdf_generated": True,
            "quote_number": _safe_str(quote_data.get("quote_number"), document_number),
            "buyer_rfq_number": _extract_buyer_rfq_number(quote_data),
            "document_number": document_number,
            "pdf_path": str(pdf_path),
            "generated_at": datetime.utcnow().isoformat() + "Z",
        }

    @classmethod
    def _draw_document(
        cls,
        c: canvas.Canvas,
        width: float,
        height: float,
        quote_data: Dict[str, Any],
        logo_path: Optional[str] = None,
        document_number: str = "LMCP-QUOTE",
    ) -> None:
        left_margin = 16 * mm
        right_margin = 16 * mm
        top_margin = 16 * mm
        bottom_margin = 15 * mm
        usable_width = width - left_margin - right_margin

        seller = quote_data.get("seller", {}) or {}
        buyer = quote_data.get("buyer", {}) or {}
        items = quote_data.get("items", []) or []
        totals = quote_data.get("totals", {}) or {}
        notes = quote_data.get("notes", []) or []

        y = height - top_margin

        y = cls._draw_header(
            c=c,
            x=left_margin,
            y=y,
            width=usable_width,
            quote_data=quote_data,
            seller=seller,
            logo_path=logo_path,
            document_number=document_number,
        )

        y -= 5 * mm

        y = cls._draw_summary_banner(
            c=c,
            x=left_margin,
            y=y,
            width=usable_width,
            quote_data=quote_data,
        )

        y -= 5 * mm

        y = cls._draw_party_blocks(
            c=c,
            x=left_margin,
            y=y,
            width=usable_width,
            buyer=buyer,
            seller=seller,
        )

        y -= 5 * mm

        y = cls._draw_quote_meta(
            c=c,
            x=left_margin,
            y=y,
            width=usable_width,
            quote_data=quote_data,
            document_number=document_number,
        )

        y -= 5 * mm

        y = cls._draw_items_table(
            c=c,
            x=left_margin,
            y=y,
            width=usable_width,
            items=items,
            bottom_limit=bottom_margin,
            page_width=width,
            page_height=height,
            quote_data=quote_data,
            logo_path=logo_path,
            document_number=document_number,
        )

        y -= 5 * mm

        if y < bottom_margin + 60 * mm:
            c.showPage()
            y = height - top_margin
            y = cls._draw_header(
                c=c,
                x=left_margin,
                y=y,
                width=usable_width,
                quote_data=quote_data,
                seller=seller,
                logo_path=logo_path,
                compact=True,
                document_number=document_number,
            )
            y -= 6 * mm

        y = cls._draw_totals_box(
            c=c,
            x=left_margin,
            y=y,
            width=usable_width,
            totals=totals,
        )

        y -= 6 * mm

        cls._draw_notes_and_footer(
            c=c,
            x=left_margin,
            y=y,
            width=usable_width,
            notes=notes,
            seller=seller,
            quote_data=quote_data,
            bottom_margin=bottom_margin,
            page_width=width,
        )

    @classmethod
    def _draw_header(
        cls,
        c: canvas.Canvas,
        x: float,
        y: float,
        width: float,
        quote_data: Dict[str, Any],
        seller: Dict[str, Any],
        logo_path: Optional[str] = None,
        compact: bool = False,
        document_number: str = "LMCP-QUOTE",
    ) -> float:
        company_name = _safe_str(seller.get("company_name"), DEFAULT_COMPANY_NAME)
        address = _safe_str(seller.get("address"), DEFAULT_SELLER_ADDRESS)
        phone = _safe_str(seller.get("phone"), DEFAULT_SELLER_PHONE)
        email = _safe_str(seller.get("email"), DEFAULT_SELLER_EMAIL)
        reg_no = _safe_str(seller.get("registration_number"), DEFAULT_SELLER_REG_NO)
        vat_no = _safe_str(seller.get("vat_number"), DEFAULT_SELLER_VAT_NO)

        box_height = 32 * mm if not compact else 22 * mm
        c.setLineWidth(1)
        c.rect(x, y - box_height, width, box_height)

        text_x = x + 5 * mm
        if logo_path:
            logo_file = Path(logo_path)
            if logo_file.exists():
                try:
                    c.drawImage(
                        str(logo_file),
                        x + 4 * mm,
                        y - 22 * mm,
                        width=16 * mm,
                        height=16 * mm,
                        preserveAspectRatio=True,
                        mask="auto",
                    )
                    text_x = x + 23 * mm
                except Exception:
                    pass

        title_x = x + width - 5 * mm
        top_text_y = y - 6 * mm

        c.setFont("Helvetica-Bold", 15 if not compact else 12)
        c.drawString(text_x, top_text_y, company_name)

        c.setFont("Helvetica-Bold", 15 if not compact else 11)
        c.drawRightString(title_x, top_text_y, "QUOTATION")

        c.setFont("Helvetica", 8)
        info_y = top_text_y - 5 * mm
        left_lines = [
            address,
            f"Tel: {phone}",
            f"Email: {email}",
            f"Reg No: {reg_no}",
            f"VAT No: {vat_no}",
        ]

        draw_y = info_y
        for line in left_lines[:5]:
            c.drawString(text_x, draw_y, line)
            draw_y -= 3.7 * mm

        c.setFont("Helvetica-Bold", 8)
        c.drawRightString(title_x, info_y, f"Quote No: {document_number}")
        c.setFont("Helvetica", 8)
        c.drawRightString(
            title_x,
            info_y - 4.2 * mm,
            f"Issue Date: {_safe_str(quote_data.get('issue_date'), datetime.utcnow().strftime('%Y-%m-%d'))}",
        )

        rfq_title = _safe_str(quote_data.get("rfq_title"), "Supply and Delivery Quotation")
        c.setFont("Helvetica-Bold", 8)
        c.drawString(x + 5 * mm, y - box_height - 4 * mm, "Subject:")
        c.setFont("Helvetica", 8)

        rfq_y = y - box_height - 4 * mm
        wrapped_title = _wrap_text(rfq_title, width - 25 * mm, "Helvetica", 8)
        for idx, line in enumerate(wrapped_title[:2]):
            c.drawString(x + 18 * mm, rfq_y - (idx * 4 * mm), line)

        return y - box_height - 12 * mm

    @classmethod
    def _draw_summary_banner(
        cls,
        c: canvas.Canvas,
        x: float,
        y: float,
        width: float,
        quote_data: Dict[str, Any],
    ) -> float:
        banner_height = 12 * mm
        c.rect(x, y - banner_height, width, banner_height)

        buyer_name = _safe_str((quote_data.get("buyer") or {}).get("company_name"), "Buyer / Issuing Entity")
        validity = f"{quote_data.get('validity_days', 30)} days"
        delivery = f"{quote_data.get('delivery_days', 14)} days"
        currency = _safe_str(quote_data.get("currency"), "ZAR")

        c.setFont("Helvetica-Bold", 8)
        c.drawString(x + 4 * mm, y - 4.8 * mm, "Buyer:")
        c.setFont("Helvetica", 8)
        c.drawString(x + 18 * mm, y - 4.8 * mm, buyer_name[:65])

        c.setFont("Helvetica-Bold", 8)
        c.drawString(x + 4 * mm, y - 9.0 * mm, "Validity:")
        c.setFont("Helvetica", 8)
        c.drawString(x + 18 * mm, y - 9.0 * mm, validity)

        c.setFont("Helvetica-Bold", 8)
        c.drawString(x + 65 * mm, y - 9.0 * mm, "Delivery:")
        c.setFont("Helvetica", 8)
        c.drawString(x + 79 * mm, y - 9.0 * mm, delivery)

        c.setFont("Helvetica-Bold", 8)
        c.drawString(x + width - 35 * mm, y - 9.0 * mm, "Currency:")
        c.setFont("Helvetica", 8)
        c.drawRightString(x + width - 4 * mm, y - 9.0 * mm, currency)

        return y - banner_height

    @classmethod
    def _draw_party_blocks(
        cls,
        c: canvas.Canvas,
        x: float,
        y: float,
        width: float,
        buyer: Dict[str, Any],
        seller: Dict[str, Any],
    ) -> float:
        gap = 5 * mm
        block_width = (width - gap) / 2
        block_height = 32 * mm

        left_x = x
        right_x = x + block_width + gap

        c.rect(left_x, y - block_height, block_width, block_height)
        c.rect(right_x, y - block_height, block_width, block_height)

        cls._draw_info_block(
            c=c,
            x=left_x + 3 * mm,
            y=y - 4 * mm,
            width=block_width - 6 * mm,
            title="Buyer / Client Details",
            lines=[
                _safe_str(buyer.get("company_name"), "Buyer / Issuing Entity"),
                _safe_str(buyer.get("contact_person"), "Procurement Office"),
                _safe_str(buyer.get("email"), "-"),
                _safe_str(buyer.get("phone"), "-"),
                _safe_str(buyer.get("address"), "South Africa"),
            ],
        )

        cls._draw_info_block(
            c=c,
            x=right_x + 3 * mm,
            y=y - 4 * mm,
            width=block_width - 6 * mm,
            title="Supplier Details",
            lines=[
                _safe_str(seller.get("company_name"), DEFAULT_COMPANY_NAME),
                _safe_str(seller.get("email"), DEFAULT_SELLER_EMAIL),
                _safe_str(seller.get("phone"), DEFAULT_SELLER_PHONE),
                _safe_str(seller.get("address"), DEFAULT_SELLER_ADDRESS),
                f"Reg No: {_safe_str(seller.get('registration_number'), DEFAULT_SELLER_REG_NO)}",
            ],
        )

        return y - block_height

    @classmethod
    def _draw_info_block(
        cls,
        c: canvas.Canvas,
        x: float,
        y: float,
        width: float,
        title: str,
        lines: List[str],
    ) -> None:
        c.setFont("Helvetica-Bold", 8.5)
        c.drawString(x, y, title)
        c.setFont("Helvetica", 8)

        draw_y = y - 5 * mm
        for raw_line in lines:
            if not raw_line:
                continue
            wrapped = _wrap_text(raw_line, width, "Helvetica", 8)
            for line in wrapped[:2]:
                c.drawString(x, draw_y, line)
                draw_y -= 3.8 * mm

    @classmethod
    def _draw_quote_meta(
        cls,
        c: canvas.Canvas,
        x: float,
        y: float,
        width: float,
        quote_data: Dict[str, Any],
        document_number: str,
    ) -> float:
        box_height = 20 * mm
        c.rect(x, y - box_height, width, box_height)

        left_x = x + 4 * mm
        right_x = x + width / 2 + 2 * mm
        start_y = y - 5 * mm

        meta_left = [
            ("Reference", document_number),
            ("RFQ ID", _safe_str(quote_data.get("rfq_id"), "-")),
            ("Submission", _safe_str(quote_data.get("submission_method"), "unknown")),
        ]
        meta_right = [
            ("Validity", f"{quote_data.get('validity_days', 30)} days"),
            ("Delivery", f"{quote_data.get('delivery_days', 14)} days"),
            ("Payment", "30 days from statement"),
        ]

        cls._draw_meta_column(c, left_x, start_y, meta_left)
        cls._draw_meta_column(c, right_x, start_y, meta_right)

        return y - box_height

    @classmethod
    def _draw_meta_column(
        cls,
        c: canvas.Canvas,
        x: float,
        y: float,
        rows: List[tuple[str, str]],
    ) -> None:
        draw_y = y
        for label, value in rows:
            c.setFont("Helvetica-Bold", 8)
            c.drawString(x, draw_y, f"{label}:")
            c.setFont("Helvetica", 8)
            c.drawString(x + 24 * mm, draw_y, value or "-")
            draw_y -= 4.5 * mm

    @classmethod
    def _draw_items_table(
        cls,
        c: canvas.Canvas,
        x: float,
        y: float,
        width: float,
        items: List[Dict[str, Any]],
        bottom_limit: float,
        page_width: float,
        page_height: float,
        quote_data: Dict[str, Any],
        logo_path: Optional[str] = None,
        document_number: str = "LMCP-QUOTE",
    ) -> float:
        col_widths = [
            12 * mm,   # no
            82 * mm,   # description
            16 * mm,   # unit
            18 * mm,   # qty
            26 * mm,   # unit price
            26 * mm,   # total
        ]

        header_height = 8 * mm
        min_row_height = 8 * mm

        def draw_table_header(current_y: float) -> float:
            headers = ["No.", "Description", "Unit", "Qty", "Unit Price", "Line Total"]
            c.setFont("Helvetica-Bold", 8)
            c.rect(x, current_y - header_height, width, header_height)

            running_x = x
            for idx, header in enumerate(headers):
                c.drawString(running_x + 2 * mm, current_y - 5.2 * mm, header)
                running_x += col_widths[idx]
                if idx < len(headers) - 1:
                    c.line(running_x, current_y, running_x, current_y - header_height)
            return current_y - header_height

        current_y = draw_table_header(y)

        for item in items:
            description_lines = _wrap_text(
                _safe_str(item.get("description"), "Supply item"),
                col_widths[1] - 4 * mm,
                "Helvetica",
                8,
            )
            row_height = max(min_row_height, (len(description_lines) * 4.2 * mm) + 3 * mm)

            if current_y - row_height < bottom_limit + 24 * mm:
                c.showPage()
                left_margin = 16 * mm
                top_margin = 16 * mm
                usable_width = page_width - (2 * left_margin)
                seller = quote_data.get("seller", {}) or {}
                current_y = page_height - top_margin
                current_y = cls._draw_header(
                    c=c,
                    x=left_margin,
                    y=current_y,
                    width=usable_width,
                    quote_data=quote_data,
                    seller=seller,
                    logo_path=logo_path,
                    compact=True,
                    document_number=document_number,
                )
                current_y -= 5 * mm
                current_y = draw_table_header(current_y)

            c.rect(x, current_y - row_height, width, row_height)

            running_x = x
            for divider in col_widths[:-1]:
                running_x += divider
                c.line(running_x, current_y, running_x, current_y - row_height)

            c.setFont("Helvetica", 8)
            c.drawString(x + 2 * mm, current_y - 5.2 * mm, _safe_str(item.get("line_number"), "-"))

            desc_y = current_y - 5.2 * mm
            for line in description_lines:
                c.drawString(x + col_widths[0] + 2 * mm, desc_y, line)
                desc_y -= 4 * mm

            c.drawString(
                x + col_widths[0] + col_widths[1] + 2 * mm,
                current_y - 5.2 * mm,
                _safe_str(item.get("unit"), "Each"),
            )

            qty_x = x + col_widths[0] + col_widths[1] + col_widths[2]
            unit_price_x = qty_x + col_widths[3]
            line_total_x = unit_price_x + col_widths[4]

            c.drawRightString(qty_x + col_widths[3] - 2 * mm, current_y - 5.2 * mm, _safe_str(item.get("quantity"), "1"))
            c.drawRightString(unit_price_x + col_widths[4] - 2 * mm, current_y - 5.2 * mm, _format_currency(item.get("unit_price")))
            c.drawRightString(line_total_x + col_widths[5] - 2 * mm, current_y - 5.2 * mm, _format_currency(item.get("line_total")))

            current_y -= row_height

        return current_y

    @classmethod
    def _draw_totals_box(
        cls,
        c: canvas.Canvas,
        x: float,
        y: float,
        width: float,
        totals: Dict[str, Any],
    ) -> float:
        box_width = 78 * mm
        box_height = 28 * mm
        box_x = x + width - box_width

        c.rect(box_x, y - box_height, box_width, box_height)

        rows = [
            ("Subtotal Excl. VAT", _format_currency(totals.get("subtotal_excl_vat"))),
            ("VAT", _format_currency(totals.get("vat_amount"))),
            ("Total Incl. VAT", _format_currency(totals.get("total_incl_vat"))),
        ]

        draw_y = y - 5 * mm
        for idx, (label, value) in enumerate(rows):
            c.setFont("Helvetica-Bold", 9 if idx == 2 else 8)
            c.drawString(box_x + 3 * mm, draw_y, label)
            c.drawRightString(box_x + box_width - 3 * mm, draw_y, value)
            draw_y -= 7 * mm

        return y - box_height

    @classmethod
    def _draw_notes_and_footer(
        cls,
        c: canvas.Canvas,
        x: float,
        y: float,
        width: float,
        notes: List[str],
        seller: Dict[str, Any],
        quote_data: Dict[str, Any],
        bottom_margin: float,
        page_width: float,
    ) -> None:
        required_space = 38 * mm
        if y < bottom_margin + required_space:
            c.showPage()
            y = A4[1] - 18 * mm

        c.setFont("Helvetica-Bold", 9)
        c.drawString(x, y, "Notes and Conditions")

        c.setFont("Helvetica", 8)
        draw_y = y - 5 * mm

        note_lines: List[str] = []
        for note in notes[:5]:
            wrapped = _wrap_text(f"- {note}", width, "Helvetica", 8)
            note_lines.extend(wrapped)

        if not note_lines:
            note_lines = [
                "- Pricing is based on the information available at RFQ stage.",
                "- Final supply quantities remain subject to buyer confirmation.",
            ]

        for line in note_lines[:8]:
            c.drawString(x, draw_y, line)
            draw_y -= 4 * mm

        draw_y -= 2 * mm
        c.setFont("Helvetica-Bold", 9)
        c.drawString(x, draw_y, "Payment Terms")
        c.setFont("Helvetica", 8)

        payment_terms = _safe_str(
            quote_data.get("payment_terms"),
            "Payment due within 30 days from statement unless otherwise agreed in writing.",
        )
        draw_y -= 5 * mm
        for line in _wrap_text(payment_terms, width, "Helvetica", 8):
            c.drawString(x, draw_y, line)
            draw_y -= 4 * mm

        footer_y = bottom_margin - 1 * mm
        c.line(x, footer_y + 6 * mm, page_width - x, footer_y + 6 * mm)
        c.setFont("Helvetica", 7.5)

        footer_company = _safe_str(seller.get("company_name"), DEFAULT_COMPANY_NAME)
        footer_contact = f"{_safe_str(seller.get('phone'), DEFAULT_SELLER_PHONE)} | {_safe_str(seller.get('email'), DEFAULT_SELLER_EMAIL)}"
        footer_address = _safe_str(seller.get("address"), DEFAULT_SELLER_ADDRESS)

        c.drawString(x, footer_y + 2 * mm, footer_company)
        c.drawCentredString(page_width / 2, footer_y + 2 * mm, footer_address)
        c.drawRightString(page_width - x, footer_y + 2 * mm, footer_contact)

    @classmethod
    def generate_quote_pack(
        cls,
        quote_data: Dict[str, Any],
        output_dir: Optional[str] = None,
        logo_path: Optional[str] = None,
    ) -> Dict[str, Any]:
        return cls.generate_quote_pdf(
            quote_data=quote_data,
            output_dir=output_dir,
            logo_path=logo_path,
        )


def generate_quote_pdf(
    quote_data: Dict[str, Any],
    output_dir: Optional[str] = None,
    logo_path: Optional[str] = None,
) -> Dict[str, Any]:
    return QuotePackService.generate_quote_pdf(
        quote_data=quote_data,
        output_dir=output_dir,
        logo_path=logo_path,
    )


def generate_quote_pack(
    quote_data: Dict[str, Any],
    output_dir: Optional[str] = None,
    logo_path: Optional[str] = None,
) -> Dict[str, Any]:
    return QuotePackService.generate_quote_pack(
        quote_data=quote_data,
        output_dir=output_dir,
        logo_path=logo_path,
    )
