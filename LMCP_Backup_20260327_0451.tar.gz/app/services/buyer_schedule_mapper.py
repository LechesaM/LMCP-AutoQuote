from __future__ import annotations

from typing import Any, Dict, List, Optional


BUYER_COLUMN_SYNONYMS = {
    "item_no": [
        "item no",
        "item number",
        "item",
        "line",
        "line no",
        "line number",
        "no",
        "#",
    ],
    "description": [
        "description",
        "item description",
        "goods description",
        "service description",
        "specification",
        "details",
        "product description",
        "scope",
    ],
    "quantity": [
        "qty",
        "quantity",
        "estimated quantity",
        "required quantity",
        "vol",
        "volume",
        "number required",
        "units",
    ],
    "unit": [
        "unit",
        "uom",
        "measure",
        "unit of measure",
    ],
    "unit_price": [
        "unit price",
        "rate",
        "price",
        "price per unit",
        "cost per unit",
        "bid rate",
        "tendered rate",
        "quoted rate",
    ],
    "total": [
        "total",
        "amount",
        "line total",
        "extended amount",
        "total amount",
        "bid amount",
        "tendered amount",
    ],
}


def _normalize_column_name(value: Any) -> str:
    """
    Normalize a buyer spreadsheet column name for matching.
    """
    text = str(value or "").strip().lower()
    text = text.replace("_", " ")
    text = text.replace("-", " ")
    text = " ".join(text.split())
    return text


def _safe_float(value: Any, default: float = 0.0) -> float:
    """
    Convert spreadsheet values to float safely.
    """
    if value is None:
        return default

    if isinstance(value, (int, float)):
        return float(value)

    text = str(value).strip()
    if not text:
        return default

    text = text.replace(",", "")
    text = text.replace("R", "")
    text = text.replace("r", "")
    text = text.strip()

    try:
        return float(text)
    except Exception:
        return default


def _find_best_column(columns: List[str], aliases: List[str]) -> Optional[str]:
    """
    Find the best matching buyer column from available columns.
    """
    normalized_columns = {_normalize_column_name(col): col for col in columns}
    alias_set = {_normalize_column_name(alias) for alias in aliases}

    # 1. Exact alias match
    for normalized, original in normalized_columns.items():
        if normalized in alias_set:
            return original

    # 2. Alias contained in column or column contained in alias
    for normalized, original in normalized_columns.items():
        for alias in alias_set:
            if alias in normalized or normalized in alias:
                return original

    return None


def map_buyer_schedule_columns(columns: List[str]) -> Dict[str, Optional[str]]:
    """
    Map arbitrary buyer schedule column headers to LMCP standard fields.

    Returns a dict like:
    {
        "item_no": "Item No",
        "description": "Description",
        "quantity": "Qty",
        "unit": "Unit",
        "unit_price": "Rate",
        "total": "Amount",
    }
    """
    mapped: Dict[str, Optional[str]] = {}

    for standard_field, aliases in BUYER_COLUMN_SYNONYMS.items():
        mapped[standard_field] = _find_best_column(columns, aliases)

    return mapped


def normalize_buyer_schedule_rows(
    rows: List[Dict[str, Any]],
    column_map: Dict[str, Optional[str]],
) -> List[Dict[str, Any]]:
    """
    Convert buyer schedule rows into a normalized LMCP structure.

    Output format:
    [
        {
            "item_no": "1",
            "description": "Supply A4 paper",
            "quantity": 10.0,
            "unit": "ream",
            "unit_price": 120.00,
            "total": 1200.00,
        }
    ]
    """
    normalized_rows: List[Dict[str, Any]] = []

    for index, row in enumerate(rows, start=1):
        item_no_col = column_map.get("item_no")
        description_col = column_map.get("description")
        quantity_col = column_map.get("quantity")
        unit_col = column_map.get("unit")
        unit_price_col = column_map.get("unit_price")
        total_col = column_map.get("total")

        item_no = row.get(item_no_col) if item_no_col else index
        description = row.get(description_col) if description_col else ""
        quantity = _safe_float(row.get(quantity_col), default=0.0) if quantity_col else 0.0
        unit = row.get(unit_col) if unit_col else ""
        unit_price = _safe_float(row.get(unit_price_col), default=0.0) if unit_price_col else 0.0
        total = _safe_float(row.get(total_col), default=0.0) if total_col else 0.0

        if not total and quantity and unit_price:
            total = round(quantity * unit_price, 2)

        normalized_rows.append(
            {
                "item_no": str(item_no).strip() if item_no is not None else str(index),
                "description": str(description or "").strip(),
                "quantity": quantity,
                "unit": str(unit or "").strip(),
                "unit_price": round(unit_price, 2),
                "total": round(total, 2),
            }
        )

    return normalized_rows


def map_and_normalize_buyer_schedule(rows: List[Dict[str, Any]]) -> Dict[str, Any]:
    """
    One-shot helper:
    - inspects incoming buyer rows
    - maps columns
    - normalizes rows

    Returns:
    {
        "column_map": {...},
        "rows": [...]
    }
    """
    if not rows:
        return {
            "column_map": {
                "item_no": None,
                "description": None,
                "quantity": None,
                "unit": None,
                "unit_price": None,
                "total": None,
            },
            "rows": [],
        }

    columns = list(rows[0].keys())
    column_map = map_buyer_schedule_columns(columns)
    normalized_rows = normalize_buyer_schedule_rows(rows, column_map)

    return {
        "column_map": column_map,
        "rows": normalized_rows,
    }
