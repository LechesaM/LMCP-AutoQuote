from typing import Any, Dict, List

from app.services.tender_harvester import run_national_tender_radar


def _safe_len(value: Any) -> int:
    if isinstance(value, list):
        return len(value)
    return 0


def run_autonomous_cycle(db: Any = None) -> Dict[str, Any]:
    radar_output = run_national_tender_radar(db=db)

    results: List[Dict[str, Any]] = radar_output.get("results", []) if isinstance(radar_output, dict) else []

    quote_ready_results = [r for r in results if bool(r.get("quote_ready"))]
    supply_results = [r for r in results if bool(r.get("is_supply"))]

    return {
        "status": "success",
        "enabled": bool(radar_output.get("enabled", False)),
        "sources_scanned": radar_output.get("sources_scanned", 0),
        "opportunities_found": _safe_len(results),
        "supply_opportunities": _safe_len(supply_results),
        "quote_ready": _safe_len(quote_ready_results),
        "results": results,
    }


def get_autonomous_status() -> Dict[str, Any]:
    return {
        "status": "ready",
        "engine": "lmcp_autonomous_engine",
        "radar_enabled": True,
        "mode": "supply-and-delivery-only",
    }
